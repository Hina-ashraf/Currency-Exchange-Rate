package com.example.demo.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
