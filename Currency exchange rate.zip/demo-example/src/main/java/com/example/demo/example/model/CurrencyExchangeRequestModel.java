package com.example.demo.example.model;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrencyExchangeRequestModel {
    public String From;
    public String To;
    public double Amount;


//    public String getFromCurrency() { return From; }
//    public void setFromCurrency(String From ) { this.From = From; }
//
//    public String getToCurrency() { return To; }
//    public void setToCurrency(String To ) { this.To = To; }
//
//    public double getAmount() { return Amount; }
//    public void setAmount(double Amount) { this.Amount = Amount; }


}
